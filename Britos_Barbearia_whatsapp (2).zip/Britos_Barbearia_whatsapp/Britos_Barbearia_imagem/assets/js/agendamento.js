(function () {
  var form = document.getElementById('booking-form');
  if (!form) return;

  var submitButton = form.querySelector('button[type="submit"]');
  var result = document.getElementById('booking-result');

  function showResult(message, state) {
    result.textContent = message;
    result.dataset.state = state;
    result.hidden = false;
  }

  form.addEventListener('submit', async function (event) {
    event.preventDefault();
    if (!form.reportValidity()) return;

    var formData = new FormData(form);
    var appointment = {
      nome: formData.get('nome').trim(),
      telefone: formData.get('telefone').trim(),
      data: formData.get('data'),
      hora: formData.get('hora'),
      servico: formData.get('servico')
    };

    submitButton.disabled = true;
    showResult('Enviando seu pedido de agendamento...', 'pending');

    try {
      var response;
      try {
        response = await fetch('http://localhost:3000/api/agendar', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(appointment)
        });
      } catch (error) {
        showResult('Não foi possível conectar ao servidor de agendamento. Verifique se o backend está em execução e tente novamente.', 'error');
        return;
      }

      var responseData;
      try {
        responseData = await response.json();
      } catch (error) {
        showResult('O servidor retornou uma resposta inválida. Tente novamente mais tarde.', 'error');
        return;
      }

      if (!response.ok) {
        showResult(responseData.error || 'Não foi possível enviar o agendamento. Confira os dados e tente novamente.', 'error');
        return;
      }

      form.reset();
      showResult('Pedido enviado com sucesso! Nossa equipe confirmará seu agendamento.', 'success');
    } finally {
      submitButton.disabled = false;
    }
  });
})();
