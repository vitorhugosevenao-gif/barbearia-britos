# Britos Barbearia — Site institucional

Site de uma página principal (landing page) mais páginas de apoio para a **Britos Barbearia**, barbearia no Jardim Nordeste (Arthur Alvim), São Paulo/SP. O site apresenta planos de assinatura, serviços avulsos, endereço, fotos de cortes, produtos e marcas parceiras, e leva o cliente para o **agendamento pelo WhatsApp**.

É um projeto **estático**: HTML + CSS + JavaScript puro, sem framework e sem etapa de build. Basta abrir os arquivos no navegador ou publicar a pasta em qualquer hospedagem estática.

---

## Sumário

1. [Dados do negócio usados no site](#1-dados-do-negócio-usados-no-site)
2. [Tecnologias e serviços externos](#2-tecnologias-e-serviços-externos)
3. [Estrutura de pastas](#3-estrutura-de-pastas)
4. [Páginas do site](#4-páginas-do-site)
5. [Seções da página inicial (index.html)](#5-seções-da-página-inicial-indexhtml)
6. [Arquitetura do CSS](#6-arquitetura-do-css)
7. [JavaScript: o que cada script faz](#7-javascript-o-que-cada-script-faz)
8. [Componentes em detalhe](#8-componentes-em-detalhe)
9. [Formulário de atendimento (SAC)](#9-formulário-de-atendimento-sac)
10. [Acessibilidade](#10-acessibilidade)
11. [Performance](#11-performance)
12. [Como rodar localmente](#12-como-rodar-localmente)
13. [Como publicar](#13-como-publicar)
14. [Guia de manutenção (como alterar cada coisa)](#14-guia-de-manutenção-como-alterar-cada-coisa)
15. [Pendências antes de ir ao ar](#15-pendências-antes-de-ir-ao-ar)
16. [Limitações conhecidas](#16-limitações-conhecidas)
17. [Direitos de imagem e marcas](#17-direitos-de-imagem-e-marcas)
18. [API de agendamentos](#18-api-de-agendamentos)

---

## 1. Dados do negócio usados no site

| Item | Valor |
|---|---|
| Nome | Britos Barbearia |
| Endereço | Rua Brook Taylor, 471 — Jardim Nordeste (Arthur Alvim) |
| Coordenadas | -23.5539, -46.4592 (latitude, longitude) |
| WhatsApp / telefone | (11) 96146-7020 (`https://wa.me/5511961467020`) |
| Instagram | @britos_barbearia_ |
| E-mail do SAC | sac@britosbarbearia.com.br |
| Tempo de resposta do SAC (informado na página) | até 2 dias úteis |

Esses dados aparecem em vários arquivos (cabeçalho, seção "Onde estamos", rodapé, SAC, páginas legais). Se algum mudar, use a busca do editor para trocar em todos os `.html` (veja o [guia de manutenção](#14-guia-de-manutenção-como-alterar-cada-coisa)).

---

## 2. Tecnologias e serviços externos

**Linguagens:** HTML5, CSS3 (variáveis CSS, grid, flexbox, `clip-path`, `mask-image`, `aspect-ratio`), JavaScript (ES5/ES6, sem dependências próprias).

**Serviços de terceiros usados em tempo de execução:**

| Serviço | Para quê | Onde |
|---|---|---|
| Google Fonts | Fontes *Big Shoulders Display* (títulos) e *Montserrat* (texto) | `<head>` de todas as páginas |
| cdnjs (Cloudflare) | Biblioteca **three.js r128** (gráficos 3D) | carregada pelo script do `index.html` |
| FormSubmit | Recebe o formulário do SAC e envia por e-mail | `sac.html` |
| WhatsApp (`wa.me`) | Botões de agendamento e botão flutuante | todas as páginas |
| Instagram | Link para o perfil | `index.html`, `sac.html`, rodapé |
| Google Maps | Botões "Abrir no mapa" e "Como chegar" (abrem em nova aba) | `index.html`, `sac.html` |

O site **não** usa cookies de publicidade nem ferramentas de analytics (isso está declarado na Política de Privacidade; se adicionar algo assim, atualize o texto).

---

## 3. Estrutura de pastas

```
Britos_Barbearia_imagem/
├── index.html              Página principal (landing page)
├── sac.html                Atendimento ao cliente (contatos + formulário)
├── privacidade.html        Política de Privacidade (LGPD)
├── termos.html             Termos de Uso
├── acessibilidade.html     Declaração de acessibilidade
├── 404.html                Página de erro "não encontrada"
├── README.md               Este arquivo
└── assets/
    ├── css/                Estilos, um arquivo por parte do site (veja seção 6)
    │   ├── base.css
    │   ├── header.css
    │   ├── components.css
    │   ├── hero.css
    │   ├── planos.css
    │   ├── servicos.css
    │   ├── agendamento.css
    │   ├── onde-estamos.css
    │   ├── sobre.css
    │   ├── produtos.css
    │   ├── galeria.css
    │   ├── parceiros.css
    │   ├── footer.css
    │   ├── sac.css
    │   ├── paginas-texto.css
    │   └── erro-404.css
    ├── js/
    │   ├── hero-3d.js      Modelos 3D (placa, pomada, óleo, shampoo) com three.js
    │   └── agendamento.js  Envio do formulário para a API de agendamentos
    └── img/
        ├── emblema-branco.png        Emblema do barbudo (ícone do menu e do 404)
        ├── logo-branco.png           Logo completa (rodapé)
        ├── fachada.jpg               Foto da fachada (seção "Onde estamos")
        ├── barbeiro-atendimento.jpg  Foto da seção "Sobre"
        ├── galeria/                  cabelo-1.jpg … cabelo-6.jpg
        └── parceiros/                Logos das marcas (.webp)
```

---

## 4. Páginas do site

| Página | Objetivo | CSS que carrega (nesta ordem) |
|---|---|---|
| `index.html` | Landing page com todas as seções | base, header, components, hero, planos, servicos, agendamento, onde-estamos, sobre, produtos, galeria, parceiros, footer |
| `sac.html` | Canais de contato e formulário de SAC | base, header, components, sac, footer |
| `privacidade.html` | Política de Privacidade (LGPD) | base, header, components, paginas-texto, footer |
| `termos.html` | Termos de Uso | base, header, components, paginas-texto, footer |
| `acessibilidade.html` | Compromisso e limitações de acessibilidade | base, header, components, paginas-texto, footer |
| `404.html` | Erro de página não encontrada (com `noindex`) | base, header, components, erro-404, footer |

Todas as páginas compartilham o mesmo cabeçalho (emblema + "Britos" + menu), o mesmo rodapé com links legais e o botão flutuante do WhatsApp.

---

## 5. Seções da página inicial (index.html)

A página alterna faixas de cor (escuro / claro / cinza) separadas por um divisor de triângulos (`.tri`). Ordem real das seções:

| # | Seção | Fundo | Âncora | O que mostra |
|---|---|---|---|---|
| 1 | **Cabeçalho** | escuro | — | Emblema + "Britos" e menu: Planos, Serviços, Onde estamos, Sobre, Galeria |
| 2 | **Hero** | escuro | `#topo` | Wordmark "Britos / Barbearia", **placa 3D** com o emblema, título "Corte, barba e estilo com hora marcada.", botões "Agende seu horário" e "Ver planos", e linha com bairro, Instagram e WhatsApp |
| 3 | **Planos Britos** | claro | `#planos` | 3 planos mensais: **Corte** (R$ 60), **Corte + Barba** (R$ 140, destacado como "Mais escolhido") e **Master** (R$ 219). Cada botão abre o WhatsApp com mensagem pronta sobre aquele plano |
| 4 | **Serviços avulsos** | cinza-claro | `#servicos` | Corte R$ 30, Barba R$ 40, Corte + Barba R$ 70, Sobrancelha R$ 15, Pézinho R$ 10, Pigmentação R$ 60 |
| 5 | **Agendamento online** | claro | `#agendamento` | Formulário de nome, telefone, serviço, data e horário enviado à API |
| 6 | **Onde estamos** | escuro | `#onde` | Foto da fachada, endereço, telefone, Instagram, botões de agendamento, mapa e distância |
| 7 | **Sobre a Britos** | cinza-escuro | `#sobre` | Texto institucional e foto do atendimento com **animação de revelação** ao rolar |
| 8 | **Galeria** | escuro | `#galeria` | 6 fotos de cortes em grade quadrada com efeito ao passar o mouse |
| 9 | **Produtos** | claro | — | 3 produtos em 3D (pomada matte R$ 49, óleo de barba R$ 59, shampoo 3 em 1 R$ 39). O texto da seção avisa que são itens e valores de exemplo |
| 10 | **Nossos Parceiros** | cinza-escuro | `#parceiros` | Carrossel em movimento com 6 marcas de bebidas |
| 11 | **Fale com a gente** | escuro | `#contato` | Botões Instagram e "Atendimento ao cliente" (leva ao `sac.html`) |
| 12 | **Rodapé** | escuro | `#rodape` | Logo, navegação, contato e links legais |

Os botões "Agende seu horário" levam ao formulário online da seção `#agendamento`. Os botões "Quero este plano" continuam abrindo o WhatsApp com uma mensagem pré-preenchida (`https://wa.me/5511961467020?text=...`).

---

## 6. Arquitetura do CSS

O CSS é dividido em arquivos pequenos, **um por parte do site**, em vez de um único `style.css`. Cada página carrega só o que usa.

### 6.1 Arquivos e responsabilidades

| Arquivo | Conteúdo |
|---|---|
| `base.css` | Variáveis de cor e fonte, reset, tipografia, foco visível, `.wrap` (largura máxima 1160 px), faixas `.dark / .slate / .light / .mist`, `.eyebrow`, `.mute`, divisor `.tri` e o cabeçalho de seção `.head` |
| `header.css` | Barra fixa do topo, logo e menu |
| `components.css` | Botões (`.btn`, `.solid`, `.ghost`), bloco de redes `.social` e botão flutuante do WhatsApp (`.wa-float`) |
| `hero.css` | Hero, wordmark, palco do 3D, `.cta-row`, `.facts` |
| `planos.css` | Cartões de planos |
| `servicos.css` | Grade de serviços avulsos |
| `onde-estamos.css` | Foto + dados de endereço |
| `sobre.css` | Seção Sobre e a animação de revelação da imagem |
| `produtos.css` | Grade dos produtos 3D |
| `galeria.css` | Grade da galeria e efeito de hover |
| `parceiros.css` | Carrossel de marcas em movimento |
| `footer.css` | Rodapé |
| `sac.css` | Cartões de contato e formulário |
| `paginas-texto.css` | Layout das páginas de texto longo (privacidade, termos, acessibilidade) |
| `erro-404.css` | Página 404 |

### 6.2 Design tokens (em `base.css`)

```css
--ink:        #0c0d0e;  /* preto de fundo */
--slate:      #26282b;  /* cinza grafite */
--ash:        #a3a7ab;  /* cinza para textos secundários sobre fundo escuro */
--mist:       #cfd2d4;  /* cinza claro de faixa */
--paper:      #f2f3f3;  /* branco de papel */
--mute-paper: #55595e;  /* texto secundário sobre fundo claro */
--display:    "Big Shoulders Display", ...  /* títulos, condensada */
--body:       "Montserrat", ...             /* texto corrido */
```

A identidade visual segue a fachada: faixas em grafite e branco, wordmark condensado **BRITOS**, "BARBEARIA" largo entre linhas e o emblema do barbudo no triângulo invertido (que inspira o divisor de triângulos).

### 6.3 Ordem de carregamento importa

Os `<link>` de CSS de cada página devem seguir a ordem: **`base` → `header` → `components` → arquivos específicos → `footer`**. O `base.css` precisa vir primeiro porque define as variáveis e classes que os demais usam. Se criar uma página nova, copie o bloco de links de uma página parecida.

### 6.4 Convenções

- Classes de cor de seção: `dark`, `slate`, `light`, `mist` (já definem cor do texto e do `.mute`).
- Espaçamento vertical das seções: `.band` (`clamp(56px, 9vw, 104px)`).
- Responsividade: breakpoints principais em **820 px** e **760 px**; unidades fluidas com `clamp()`.
- Preferências do usuário respeitadas: `prefers-reduced-motion` (sem animações) e `hover: none` (celulares, sem efeitos de hover).

---

## 7. JavaScript: o que cada script faz

Há cinco scripts na página, sem dependências próprias (só o three.js, de fora).

### 7.1 Carregador adiado do three.js (`index.html`, final da página)

O three.js pesa cerca de 600 KB e, carregado normalmente, trava a renderização (isso derrubava a nota de Performance). Por isso um pequeno script:

1. espera o evento `load` da página;
2. agenda com `requestIdleCallback` (com *timeout* de 2 s; se o navegador não tiver, usa `setTimeout`);
3. carrega o **three.min.js** do cdnjs e, só quando ele termina, carrega `assets/js/hero-3d.js` (a ordem é garantida pelo encadeamento de promessas);
4. se algo falhar (sem internet, bloqueio), o site continua funcionando normalmente, só sem os elementos 3D.

Há também um `<link rel="preconnect">` para o cdnjs no `<head>`, para ganhar alguns milissegundos na conexão.

### 7.2 `assets/js/hero-3d.js` — modelos 3D

Procura todos os `<canvas data-model="...">` da página e monta uma cena three.js em cada um:

| `data-model` | Onde aparece | O que desenha |
|---|---|---|
| `plaque` | Hero | Placa com o emblema da Britos |
| `jar` | Produtos | Pote de pomada |
| `oil` | Produtos | Frasco de óleo de barba |
| `shampoo` | Produtos | Frasco de shampoo |

Detalhes de funcionamento:
- Materiais metálicos/pretos (`MeshStandardMaterial`), três luzes (hemisférica, principal e de contorno) e rótulos desenhados em `CanvasTexture` com as fontes do site.
- A câmera se **ajusta automaticamente** ao tamanho do canvas (`ResizeObserver`) para o objeto sempre caber inteiro.
- O objeto **inclina acompanhando o ponteiro** (`pointermove`) sobre o palco e volta ao centro ao sair (`pointerleave`).
- **Economia de recursos:** só anima enquanto o canvas está visível (`IntersectionObserver`) e limita a densidade de pixels a 2×.
- **Acessibilidade:** com "reduzir movimento" ativado no sistema, desenha um quadro estático e não anima.
- Se o navegador não suportar WebGL, o script simplesmente não monta aquele canvas.

### 7.3 Revelação da imagem da seção Sobre (`index.html`, final da página)

Usa **`IntersectionObserver` + CSS transitions** (no lugar de `animation-timeline: view()`, que não funcionou no Brave/Chromium do projeto):

1. A imagem `.about .art img` começa com `transform: scale(1.15)` e `clip-path` escondendo a metade esquerda (definido em `sobre.css`).
2. Quando 25% da imagem entra na tela, o script adiciona a classe `.is-visible`.
3. Essa classe aplica, em 0,8 s, `scale(1)` e o `clip-path` completo (a imagem "abre" da direita para a esquerda).
4. Depois de animar, o observador para de observar (`unobserve`): a animação ocorre **uma vez**.
5. Sem suporte a `IntersectionObserver` ou com "reduzir movimento", a imagem aparece direto.

### 7.4 Distância até a barbearia (`index.html`, final da página)

O botão **Ver Distância** pede a localização atual pelo `navigator.geolocation` e calcula a distância em linha reta até as coordenadas da Britos (`-23.5539, -46.4592`) usando a Fórmula de Haversine. O resultado ou uma mensagem de erro de permissão/disponibilidade é exibido na própria seção. A localização é usada apenas no navegador para o cálculo; não é enviada nem armazenada pelo site. O navegador pode exigir que a página esteja em HTTPS e que o usuário autorize o acesso.

### 7.5 Envio de agendamentos (`assets/js/agendamento.js`)

Intercepta o `submit` do formulário `#booking-form`, envia nome, telefone, serviço, data e hora como JSON para `http://localhost:3000/api/agendar` e mostra o resultado na página. Durante o envio, desativa o botão para evitar duplicidades; em falhas, mantém os dados preenchidos para permitir uma nova tentativa. O backend precisa estar em execução e aceitar CORS da origem da página.

---

## 8. Componentes em detalhe

### 8.1 Botões

`.btn` é a base. Variações: `.solid` (preenchido, cor de papel) e `.ghost` (apenas contorno). O botão do WhatsApp flutuante (`.wa-float`) fica fixo no canto inferior direito de **todas** as páginas e tem `aria-label` para leitores de tela.

### 8.2 Galeria (`galeria.css`)

- Grade de **3 colunas × 2 linhas** no desktop; 2 colunas até 820 px.
- Cada foto é um `<figure class="gallery-item">` quadrado (`aspect-ratio: 1/1`) com `object-fit: cover`.
- O enquadramento (qual parte da foto fica visível) é ajustado por foto com a variável `--pos` no próprio `<img>` (ex.: `style="--pos: 50% 22%"`), para manter o rosto/cabelo no quadro.
- **Hover/foco:** zoom suave, leve escurecimento, moldura branca interna que "fecha" e legenda que sobe sobre um degradê escuro. Funciona também com **teclado** (`tabindex="0"` + `:focus-visible`).
- Em telas sem hover (celular) as legendas ficam sempre visíveis.
- As fotos em `assets/img/galeria/` já estão otimizadas (largura máxima de 900 px, JPEG progressivo).

### 8.3 Carrossel de parceiros (`parceiros.css`)

Carrossel infinito feito **só com CSS** (animação `marquee-scroll`).

**Estrutura:** `.marquee` (janela) → `.marquee-track` (faixa que se move) → **3** `.marquee-group` idênticos → `.partner-item` (cartões).

**Como o loop é contínuo:** a faixa anda `-33,3333%` (exatamente a largura de um grupo) e volta ao início; como os grupos são iguais, não há emenda visível. Três grupos garantem que nunca apareça espaço vazio em telas largas.

**Detalhes:**
- Largura limitada ao conteúdo (`width: min(1128px, 100% - 32px)`), alinhada ao título, com as bordas esmaecendo por `mask-image`.
- Cartões de 220 px (160 px no celular), proporção 3:2, logo centralizado com `object-fit: contain` (nunca corta o logo).
- Logos em **escala de cinza** por padrão; no hover/foco ganham cor, dão zoom e mostram a legenda com o nome.
- **Pausa** ao passar o mouse ou focar com o teclado.
- Logos de letras brancas (ex.: Pepsi) usam a classe `is-dark`, que troca o cartão para fundo escuro.
- Só o **primeiro grupo** é lido por leitores de tela; os outros dois são cópias com `aria-hidden="true"` e `alt=""`.
- Com "reduzir movimento": sem animação, mostra um grupo só, com rolagem lateral manual.

**Marcas atuais:** Coca-Cola, Fanta, Sprite, Pepsi, Guaraná Antarctica Zero e Heineken (`assets/img/parceiros/*.webp`, já cortadas e otimizadas).

### 8.4 Cartões de planos e serviços

`planos.css` e `servicos.css` usam grid. O plano **Corte + Barba** tem a classe `feat` e uma etiqueta "Mais escolhido" para destacar a opção principal.

### 8.5 Divisor de triângulos

`<div class="tri on-dark|on-light" aria-hidden="true">` desenha uma fileira de triângulos invertidos entre seções, ecoando o emblema. É decorativo (escondido de leitores de tela).

### 8.6 Páginas de texto (privacidade, termos, acessibilidade)

Usam o container `.doc` (largura de leitura confortável) dentro de uma faixa clara. Cada uma tem a data "Última atualização" no topo.

### 8.7 Página 404

Faixa escura centralizada com um "4 [emblema] 4" gigante (o emblema do barbudo faz o papel do zero), título, texto, três botões (início, planos, WhatsApp) e atalhos para seções. Usa `<meta name="robots" content="noindex">`.

---

## 9. Formulário de atendimento (SAC)

Em `sac.html`. Canais exibidos acima do formulário: WhatsApp, e-mail e Instagram.

**Campos:** nome completo (obrigatório), e-mail (obrigatório), telefone/WhatsApp (opcional), assunto (obrigatório — Dúvida sobre planos, Dúvida sobre serviços, Reclamação, Elogio, Sugestão, Acessibilidade, Privacidade/LGPD, Outro), mensagem (obrigatório) e caixa de **consentimento** (obrigatória) com links para a Política de Privacidade e os Termos.

**Como funciona o envio:** o `<form>` faz `POST` para `https://formsubmit.co/sac@britosbarbearia.com.br`. O FormSubmit recebe os dados e os encaminha por e-mail. Campos ocultos usados:

| Campo | Função |
|---|---|
| `_subject` | Assunto do e-mail recebido ("Novo contato pelo SAC - Site Britos") |
| `_template` | Formato do e-mail (`table`) |
| `_captcha` | `false` desativa o captcha do FormSubmit |
| `_honey` | Campo-isca invisível contra robôs (spam) |

**Importante — ativação:** na **primeira** vez que alguém enviar o formulário, o FormSubmit manda um e-mail de confirmação para `sac@britosbarbearia.com.br`. É preciso **abrir e confirmar** esse e-mail; só depois as mensagens passam a chegar. Faça um envio de teste logo após publicar.

Como o FormSubmit trata os dados, ele é citado como operador na Política de Privacidade.

---

## 10. Acessibilidade

O que o projeto já faz (e está declarado em `acessibilidade.html`):

- Estrutura semântica: `header`, `nav` com `aria-label`, `main`, `footer`.
- Foco visível em links e botões (`:focus-visible`) e navegação completa por teclado.
- Texto alternativo (`alt`) nas imagens informativas; imagens decorativas com `alt=""`.
- Campos do formulário com `<label>` associado (`for`/`id`) e atributos `autocomplete`.
- Layout responsivo (celular, tablet, desktop) e suporte a áreas seguras de telas com notch (`env(safe-area-inset-*)`).
- `prefers-reduced-motion`: desliga animações do 3D, da revelação da imagem e do carrossel.
- Elementos 3D tratados como decorativos (`role="img"` + `aria-label` nos canvas); as informações importantes também estão em texto na página.
- Itens duplicados do carrossel escondidos de leitores de tela (`aria-hidden`).
- Cada galeria/carrossel pode ser percorrido com **Tab**.

Limitação declarada: os elementos 3D podem não ser lidos por todos os leitores de tela.

---

## 11. Performance

Medidas aplicadas:

- **three.js adiado** (seção 7.1): o maior peso de JavaScript (~600 KB) só carrega depois da página pronta. Em teste simulado, a primeira renderização caiu de ~620 ms para ~130 ms. O processamento do three.js ainda existe, então o TBT (tempo de bloqueio) pode continuar acima do ideal; se precisar reduzir mais, uma opção é carregá-lo só na primeira rolagem/interação.
- **Imagens otimizadas:** galeria em JPEG ≤ 900 px; logos de parceiros em WebP recortados (8 a 50 KB cada); `loading="lazy"` nas imagens abaixo da dobra e `width`/`height` definidos para evitar saltos de layout.
- **Animação só quando visível:** os canvas 3D pausam fora da tela.
- **Preconnect** para Google Fonts e cdnjs.

Ponto de atenção: o CSS dividido em arquivos faz a página inicial carregar **12 folhas de estilo** bloqueantes. Em hospedagens com HTTP/2 o impacto é pequeno, mas para a publicação final vale **juntar tudo em um único arquivo minificado** (veja a seção 13).

---

## 12. Como rodar localmente

**Opção simples:** abra o `index.html` com duplo clique. Funciona, mas o three.js e as fontes precisam de internet.

**Opção recomendada (servidor local):**

```bash
# dentro da pasta Britos_Barbearia_imagem
python3 -m http.server 8000
# abra http://localhost:8000
```

ou use a extensão **Live Server** do VS Code.

Para testar a página 404 localmente, abra `404.html` diretamente (o servidor simples do Python não a usa automaticamente para endereços inexistentes).

---

## 13. Como publicar

O site é 100% estático: serve em **Netlify, GitHub Pages, Vercel, Cloudflare Pages** ou qualquer hospedagem comum (envie a pasta inteira por FTP).

Checklist de publicação:

1. Confirmar a página `404.html` na **raiz** (Netlify, GitHub Pages e Vercel a usam automaticamente). Em endereços com subpastas (ex.: `/loja/teste`), os caminhos relativos do 404 podem quebrar; nesse caso, adicione `<base href="https://SEU-DOMINIO/">` no `<head>` do `404.html`.
2. Fazer um envio de teste do formulário do SAC e **confirmar o e-mail de ativação** do FormSubmit (seção 9).
3. Conferir os links do WhatsApp, Instagram e mapa.
4. Preencher as pendências legais (seção 15).
5. (Recomendado) Juntar e minificar os CSS. Exemplo simples, mantendo a ordem de carregamento da página inicial:

```bash
cd assets/css
cat base.css header.css components.css hero.css planos.css servicos.css \
    onde-estamos.css sobre.css produtos.css galeria.css parceiros.css footer.css > bundle.css
```

Depois substitua os 12 `<link>` do `index.html` por um único `<link rel="stylesheet" href="assets/css/bundle.css">` (faça o mesmo, com os arquivos certos, para as demais páginas). Mantenha os arquivos separados no repositório e gere o `bundle.css` só para publicar.

---

## 14. Guia de manutenção (como alterar cada coisa)

### Preços e planos
Edite o texto direto no `index.html`: seção `#planos` (planos) e `#servicos` (avulsos). Os produtos (R$ 49, 59, 39) estão na seção de Produtos. Lembre que os **Termos de Uso** dizem que valores podem mudar e devem ser confirmados no atendimento.

### Telefone, endereço e Instagram
Busque no projeto por `96146-7020`, `5511961467020`, `Brook Taylor` e `britos_barbearia_` e troque em todos os `.html`. Os links `wa.me` usam só números (DDI + DDD + número).

### Mensagem pronta do WhatsApp
Está no final de cada link `wa.me/...?text=...`. O texto precisa estar codificado em URL (use um "URL encode" online se mudar).

### Adicionar ou trocar foto da galeria
1. Salve a imagem (de preferência quadrada ou com o rosto centralizado, até ~900 px de largura) em `assets/img/galeria/`.
2. Em `index.html`, copie um bloco `<figure class="gallery-item" tabindex="0">…</figure>` e ajuste `src`, `alt`, a legenda e o número.
3. Se o rosto ficar cortado, ajuste `--pos` (ex.: `50% 20%` mostra mais o topo; `50% 80%` mostra mais a parte de baixo).
4. Para manter a grade 3×2 sem sobras, use múltiplos de 3 (3, 6, 9...).

### Trocar/adicionar marcas parceiras
1. Salve o logo em `assets/img/parceiros/` (PNG ou WebP com fundo transparente, ~300 a 600 px de largura).
2. No `index.html`, a seção `#parceiros` tem **3 grupos** (`.marquee-group`) com os mesmos 6 cartões. **Edite os 3 grupos do mesmo jeito.** O primeiro grupo tem `alt` com o nome da marca e `tabindex="0"`; o segundo e o terceiro têm `aria-hidden="true"` e `alt=""`.
3. Logo com letras brancas? Adicione a classe `is-dark` ao `<figure>`.
4. Quantidade ideal: 5 ou mais marcas. Com poucas marcas, a faixa pode não preencher a largura; nesse caso repita mais grupos ou aumente `--tile-w`.

### Velocidade e tamanho do carrossel
Em `parceiros.css`: `animation: marquee-scroll 30s` (maior = mais lento), `--tile-w: 220px` (tamanho do cartão) e `width: min(1128px, 100% - 32px)` (largura da janela).

### Cores e fontes
Altere as variáveis em `base.css` (`:root`). Tudo no site usa essas variáveis.

### Trocar a foto da seção Sobre / fachada
Substitua `assets/img/barbeiro-atendimento.jpg` e `assets/img/fachada.jpg` mantendo os nomes (ou ajuste o `src`) e atualize os `alt`.

### Mudar textos das páginas legais
Edite `privacidade.html`, `termos.html` e `acessibilidade.html` e **atualize a data** "Última atualização" no topo.

### Modelos 3D
Estão em `assets/js/hero-3d.js`, no objeto `builders` (`plaque`, `jar`, `oil`, `shampoo`). Para trocar o texto do rótulo ou as cores, edite as funções correspondentes. Para usar o modelo num novo lugar, adicione um `<canvas class="gl" data-model="jar">` dentro de um contêiner com `aspect-ratio` definido.

### Adicionar um link no menu
Em `index.html`, dentro de `<nav class="main">`, adicione `<a href="#parceiros">Parceiros</a>`. Atenção: o botão "Agende seu horário" do cabeçalho não está mais no menu da página inicial.

---

## 15. Pendências antes de ir ao ar

Itens que ainda estão com marcador de preenchimento ou dependem do dono do site:

- [ ] **`privacidade.html`**: trocar `[RAZÃO SOCIAL]` pela razão social (e CNPJ, se quiser) da Britos.
- [ ] **`termos.html`**: trocar `[CIDADE/UF]` pela comarca do foro (ex.: São Paulo/SP).
- [ ] Confirmar a ativação do FormSubmit para `sac@britosbarbearia.com.br` (seção 9).
- [ ] Criar/confirmar que o e-mail `sac@britosbarbearia.com.br` existe e é monitorado (a página promete resposta em até 2 dias úteis).
- [ ] Conferir se os preços e planos exibidos são os oficiais (os produtos estão marcados como "valores de exemplo").
- [ ] Confirmar autorização das marcas parceiras para uso dos logos (seção 17).
- [ ] Revisar com um advogado ou contador os textos de Privacidade (LGPD) e Termos de Uso, que são modelos e não substituem orientação jurídica.

---

## 16. Limitações conhecidas

- **Agendamento online:** o formulário envia pedidos para o backend em `http://localhost:3000`. Para publicação, configure a URL da API e as origens CORS; o servidor ainda não confirma disponibilidade de horários nem processa pagamentos.
- **Planos:** as páginas só apresentam os planos; a contratação acontece no atendimento.
- **3D depende de WebGL e de internet** (three.js vem do cdnjs). Sem isso, as áreas dos canvas ficam vazias, mas o resto do site funciona.
- **Fontes dependem do Google Fonts**; sem internet, o navegador usa as fontes de reserva (Arial Narrow/Impact e system-ui).
- **Formulário de SAC depende do FormSubmit** (serviço gratuito de terceiros, sem garantia de disponibilidade). O formulário de agendamento depende do backend em `http://localhost:3000`; o WhatsApp e o e-mail continuam disponíveis como canais de contato.
- **Logos de parceiros pequenos:** alguns arquivos originais são de baixa resolução (250 a 320 px) e podem parecer macios em telas de alta densidade; substitua por versões maiores se tiver.
- **Os elementos 3D** podem não ser descritos por todos os leitores de tela.

---

## 17. Direitos de imagem e marcas

- As fotos de clientes devem ter **autorização de uso de imagem** das pessoas fotografadas.
- Os logos das marcas parceiras (Coca-Cola, Fanta, Sprite, Pepsi, Guaraná Antarctica, Heineken) pertencem a seus titulares. Use-os somente se a Britos tiver autorização para divulgar a parceria.
- Marca, logotipo, emblema, textos e fotos próprios da Britos pertencem à Britos Barbearia (conforme os Termos de Uso do site).
- O three.js é distribuído sob licença MIT; as fontes Big Shoulders Display e Montserrat estão sob a SIL Open Font License.

---

## 18. API de agendamentos

O backend em `backend/` usa Express, SQLite3 e CORS. Para iniciar o servidor, execute:

```bash
cd backend
pnpm install
node server.js
```

O servidor escuta na porta **3000** e cria `backend/barbearia.db` e a tabela `agendamentos` automaticamente na primeira inicialização. A porta pode ser alterada com `PORT`; o caminho do banco pode ser definido com `DB_PATH`.

- `POST http://localhost:3000/api/agendar`: recebe JSON com `nome`, `telefone`, `servico`, `data` (`YYYY-MM-DD`) e `hora` (`HH:MM`); retorna o agendamento criado.
- `GET http://localhost:3000/api/agendamentos`: retorna os agendamentos ordenados por data e hora.

O endpoint GET retorna nomes e telefones. Antes de disponibilizar o backend publicamente, proteja a listagem com autenticação e configure as origens CORS apropriadas; CORS sozinho não é controle de acesso.

---

*Documentação gerada em outubro de 2026. Se alterar a estrutura do projeto, mantenha este arquivo atualizado.*
