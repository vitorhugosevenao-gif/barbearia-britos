import cors from 'cors';
import express from 'express';
import sqlite3 from 'sqlite3';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

export const app = express();
const port = Number(process.env.PORT) || 3000;
const directory = dirname(fileURLToPath(import.meta.url));
const databasePath = process.env.DB_PATH
  ? resolve(process.env.DB_PATH)
  : join(directory, 'barbearia.db');

const createAppointmentsTable = `
  CREATE TABLE IF NOT EXISTS agendamentos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    telefone TEXT NOT NULL,
    servico TEXT NOT NULL,
    data TEXT NOT NULL,
    hora TEXT NOT NULL
  )
`;

let resolveDatabaseReady;
let rejectDatabaseReady;
export const databaseReady = new Promise((resolvePromise, rejectPromise) => {
  resolveDatabaseReady = resolvePromise;
  rejectDatabaseReady = rejectPromise;
});

export const database = new sqlite3.Database(databasePath, (openError) => {
  if (openError) {
    rejectDatabaseReady(openError);
    return;
  }

  database.run(createAppointmentsTable, (schemaError) => {
    if (schemaError) {
      rejectDatabaseReady(schemaError);
      return;
    }

    resolveDatabaseReady();
  });
});

app.use(cors());
app.use(express.json({ limit: '16kb' }));

function isValidDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;

  const parsedDate = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(parsedDate.getTime()) &&
    parsedDate.toISOString().slice(0, 10) === value;
}

function validateAppointment(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return 'Envie os dados do agendamento em formato JSON.';
  }

  const fields = [
    ['nome', 120],
    ['telefone', 40],
    ['servico', 120],
    ['data', 10],
    ['hora', 5]
  ];

  for (const [field, maxLength] of fields) {
    if (typeof body[field] !== 'string' || !body[field].trim()) {
      return `O campo "${field}" é obrigatório e deve ser um texto.`;
    }

    if (body[field].trim().length > maxLength) {
      return `O campo "${field}" excede o tamanho máximo permitido.`;
    }
  }

  if (!isValidDate(body.data.trim())) {
    return 'O campo "data" deve usar o formato YYYY-MM-DD e conter uma data válida.';
  }

  if (!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(body.hora.trim())) {
    return 'O campo "hora" deve usar o formato HH:MM.';
  }

  return null;
}

function insertAppointment(values) {
  return new Promise((resolvePromise, rejectPromise) => {
    database.run(
      `INSERT INTO agendamentos (nome, telefone, servico, data, hora)
       VALUES (?, ?, ?, ?, ?)`,
      values,
      function (error) {
        if (error) {
          rejectPromise(error);
          return;
        }

        resolvePromise(this.lastID);
      }
    );
  });
}

function listAppointments() {
  return new Promise((resolvePromise, rejectPromise) => {
    database.all(
      `SELECT id, nome, telefone, servico, data, hora
       FROM agendamentos
       ORDER BY data ASC, hora ASC, id ASC`,
      (error, rows) => {
        if (error) {
          rejectPromise(error);
          return;
        }

        resolvePromise(rows);
      }
    );
  });
}

app.post('/api/agendar', async (request, response, next) => {
  const validationError = validateAppointment(request.body);

  if (validationError) {
    response.status(400).json({ error: validationError });
    return;
  }

  try {
    await databaseReady;

    const appointment = {
      nome: request.body.nome.trim(),
      telefone: request.body.telefone.trim(),
      servico: request.body.servico.trim(),
      data: request.body.data.trim(),
      hora: request.body.hora.trim()
    };
    const id = await insertAppointment(Object.values(appointment));

    response.status(201).json({ id, ...appointment });
  } catch (error) {
    next(error);
  }
});

app.get('/api/agendamentos', async (request, response, next) => {
  try {
    await databaseReady;
    response.json(await listAppointments());
  } catch (error) {
    next(error);
  }
});

app.use((request, response) => {
  response.status(404).json({ error: 'Rota não encontrada.' });
});

app.use((error, request, response, next) => {
  if (response.headersSent) {
    next(error);
    return;
  }

  if (error.type === 'entity.parse.failed') {
    response.status(400).json({ error: 'O corpo da requisição deve conter JSON válido.' });
    return;
  }

  if (error.type === 'entity.too.large') {
    response.status(413).json({ error: 'O corpo da requisição excede o limite de 16 KB.' });
    return;
  }

  console.error('Erro ao processar a requisição:', error);
  response.status(500).json({ error: 'Erro interno ao processar a requisição.' });
});

export function startServer(listenPort = port) {
  return databaseReady.then(() => new Promise((resolvePromise, rejectPromise) => {
    const server = app.listen(listenPort, () => resolvePromise(server));
    server.once('error', rejectPromise);
  }));
}

export function closeDatabase() {
  return new Promise((resolvePromise, rejectPromise) => {
    database.close((error) => {
      if (error) {
        rejectPromise(error);
        return;
      }

      resolvePromise();
    });
  });
}

const isMainModule = process.argv[1] &&
  pathToFileURL(resolve(process.argv[1])).href === import.meta.url;

if (isMainModule) {
  startServer()
    .then((server) => {
      console.log(`Servidor de agendamentos ativo na porta ${server.address().port}.`);

      const shutdown = () => {
        server.close((serverError) => {
          if (serverError) {
            console.error('Erro ao encerrar o servidor:', serverError);
            process.exitCode = 1;
          }

          closeDatabase().catch((databaseError) => {
            console.error('Erro ao fechar o banco de dados:', databaseError);
            process.exitCode = 1;
          });
        });
      };

      process.once('SIGINT', shutdown);
      process.once('SIGTERM', shutdown);
    })
    .catch((error) => {
      console.error('Não foi possível iniciar o servidor:', error);
      closeDatabase().catch((databaseError) => {
        console.error('Erro ao fechar o banco de dados:', databaseError);
      });
      process.exitCode = 1;
    });
}